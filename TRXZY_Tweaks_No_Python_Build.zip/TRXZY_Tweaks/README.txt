TRXZY Tweaks
============

A lightweight Windows gaming helper with a neon purple/black interface.

Features
- Live CPU, RAM and system-drive readings (psutil)
- Game profiles and launching
- Reversible process-priority change (Normal / Above normal / High)
- Shortcuts to Windows gaming, graphics, refresh-rate and startup settings
- Optional keyboard and mouse-button macro recording/playback (pynput)
- Local settings only; no telemetry/network calls by the app

NO PYTHON ON YOUR PC?
Read BUILD_EXE_WITHOUT_INSTALLING_PYTHON.txt. The included GitHub Actions workflow can build a standalone Windows EXE on a hosted Windows runner. This source ZIP does not itself contain a compiled EXE.

Run from source (optional)
1. Install Python 3 from https://www.python.org/downloads/windows/ and enable “Add Python to PATH”.
2. Open Command Prompt in this folder.
3. Run: py -m pip install psutil pynput
4. Run: py trxzy_tweaks.py

Important
- No tool can guarantee zero latency or a specific FPS increase.
- High process priority may make other apps less responsive; use Undo to restore the previous priority.
- Macro playback generates real keyboard/mouse-button input. Use only where permitted by the game/software; no anti-cheat bypass is included.
