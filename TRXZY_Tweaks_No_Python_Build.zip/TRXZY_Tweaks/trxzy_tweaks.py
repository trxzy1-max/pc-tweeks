import os, sys, json, time, threading, subprocess, tkinter as tk
from tkinter import ttk, filedialog, messagebox

APP_NAME = "TRXZY Tweaks"
BG="#080611"; PANEL="#110d20"; PANEL2="#17102b"; PURPLE="#8b5cf6"
PURPLE_HI="#c4b5fd"; TEXT="#f3efff"; MUTED="#aaa0c8"; GREEN="#4ade80"
RED="#fb7185"; BORDER="#30234d"
CONFIG_DIR=os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "TRXZYTweaks")
CONFIG_FILE=os.path.join(CONFIG_DIR,"config.json")

try:
    import psutil
except ImportError:
    psutil=None
try:
    from pynput import keyboard, mouse
except ImportError:
    keyboard=mouse=None

PRIORITIES={"Normal":0x20, "Above normal":0x8000, "High":0x80}
PROC_QUERY=0x1000; PROC_SET=0x0200
if os.name=="nt":
    import ctypes
    from ctypes import wintypes
    KERNEL32=ctypes.WinDLL("kernel32", use_last_error=True)
else:
    KERNEL32=None

def load_config():
    try:
        with open(CONFIG_FILE,encoding="utf-8") as f:
            d=json.load(f)
            if isinstance(d,dict): return d
    except (OSError,ValueError): pass
    return {"games":[],"selected_game":"","macros":[]}

def save_config(data):
    os.makedirs(CONFIG_DIR,exist_ok=True)
    tmp=CONFIG_FILE+".tmp"
    with open(tmp,"w",encoding="utf-8") as f: json.dump(data,f,indent=2)
    os.replace(tmp,CONFIG_FILE)

class App:
    def __init__(self,root):
        self.root=root; self.root.title("TRXZY Tweaks"); self.root.geometry("1180x790")
        self.root.minsize(980,680); self.root.configure(bg=BG)
        self.data=load_config(); self.running=None; self.changed_pid=None; self.old_priority=None
        self.recording=False; self.record_start=0; self.record_events=[]; self.record_listener=None
        self.macro_listener=None; self.macro_playing=False; self.stop_playback=threading.Event()
        self.cpu=tk.StringVar(value="—"); self.ram=tk.StringVar(value="—"); self.disk=tk.StringVar(value="—")
        self.status=tk.StringVar(value="Ready — no changes applied")
        self.priority=tk.StringVar(value="Above normal")
        self.macro_name=tk.StringVar(value="Build practice"); self.macro_delay=tk.StringVar(value="80")
        self.macro_status=tk.StringVar(value="Macros are off")
        self._style(); self._ui(); self._refresh_games(); self._refresh_macros(); self._stats()
        self.root.protocol("WM_DELETE_WINDOW",self.close)

    def style(self):
        pass
    def _style(self):
        s=ttk.Style()
        try:s.theme_use("clam")
        except tk.TclError:pass
        s.configure("TCombobox",fieldbackground=PANEL2,background=PANEL2,foreground=TEXT,arrowcolor=PURPLE_HI)
        s.map("TCombobox",fieldbackground=[("readonly",PANEL2)],foreground=[("readonly",TEXT)])
        s.configure("Treeview",background=PANEL,fieldbackground=PANEL,foreground=TEXT,rowheight=26,borderwidth=0)
        s.configure("Treeview.Heading",background=PANEL2,foreground=PURPLE_HI,relief="flat")
        s.map("Treeview",background=[("selected","#39206a")],foreground=[("selected",TEXT)])

    def label(self,p,t,size=10,color=TEXT,bold=False,**kw):
        bg = kw.pop("bg", p.cget("bg"))
        return tk.Label(p,text=t,bg=bg,fg=color,font=("Segoe UI",size,"bold" if bold else "normal"),**kw)
    def btn(self,p,t,cmd,primary=False):
        return tk.Button(p,text=t,command=cmd,bg=PURPLE if primary else PANEL2,fg="#fff" if primary else TEXT,
            activebackground=PURPLE_HI if primary else "#24183d",activeforeground="#fff",relief="flat",bd=0,
            padx=12,pady=8,cursor="hand2",font=("Segoe UI",9,"bold" if primary else "normal"))
    def card(self,p,title,desc=None):
        f=tk.Frame(p,bg=PANEL,highlightbackground=BORDER,highlightthickness=1)
        self.label(f,title,11,PURPLE_HI,True).pack(anchor="w",padx=14,pady=(12,3))
        if desc:self.label(f,desc,8,MUTED,wraplength=650,justify="left").pack(anchor="w",padx=14,pady=(0,9))
        return f
    def _ui(self):
        header=tk.Frame(self.root,bg="#0c0817",height=78,highlightbackground=BORDER,highlightthickness=1)
        header.pack(fill="x");header.pack_propagate(False)
        self.label(header,"◈",31,PURPLE,True).pack(side="left",padx=(20,10))
        box=tk.Frame(header,bg="#0c0817");box.pack(side="left",pady=10)
        self.label(box,"TRXZY Tweaks",20,TEXT,True).pack(anchor="w")
        self.label(box,"FPS • LOW LATENCY • KBM MACROS • GAME PROFILES",8,MUTED).pack(anchor="w")
        self.label(header,"WINDOWS 10 / 11  •  LOCAL ONLY",9,PURPLE_HI,True,bg=PANEL2,padx=12,pady=8).pack(side="right",padx=20)
        body=tk.Frame(self.root,bg=BG);body.pack(fill="both",expand=True,padx=17,pady=15)
        nav=tk.Frame(body,bg=BG,width=185);nav.pack(side="left",fill="y",padx=(0,15));nav.pack_propagate(False)
        self.page=tk.StringVar(value="Dashboard")
        for name,icon in [("Dashboard","⌂"),("FPS & Latency","⚡"),("KBM Macros","⌨"),("Game Profiles","🎮"),("Restore / Undo","↶")]:
            b=tk.Button(nav,text=f"{icon}  {name}",anchor="w",command=lambda n=name:self.show_page(n),
                bg=PANEL2 if name=="Dashboard" else BG,fg=TEXT if name=="Dashboard" else MUTED,
                activebackground="#24183d",activeforeground=TEXT,relief="flat",bd=0,padx=12,pady=12,
                font=("Segoe UI",10),cursor="hand2")
            b.pack(fill="x",pady=2)
        note=tk.Frame(nav,bg=PANEL,highlightbackground=BORDER,highlightthickness=1);note.pack(side="bottom",fill="x",pady=8)
        self.label(note,"REAL TWEAKS",9,GREEN,True).pack(anchor="w",padx=10,pady=(10,4))
        self.label(note,"No fake FPS claims.\nNo registry cleaners.\nUndo where possible.",8,MUTED,justify="left").pack(anchor="w",padx=10,pady=(0,10))
        self.content=tk.Frame(body,bg=BG);self.content.pack(side="left",fill="both",expand=True)
        footer=tk.Frame(self.root,bg="#0c0817",height=30);footer.pack(side="bottom",fill="x");footer.pack_propagate(False)
        self.label(footer,"TRXZY Tweaks • No telemetry • No guaranteed FPS/ping gains",8,MUTED).pack(side="left",padx=17,pady=6)
        self.show_page("Dashboard")

    def clear(self):
        for w in self.content.winfo_children():w.destroy()
    def show_page(self,name):
        self.page.set(name);self.clear()
        if name=="Dashboard":self.dashboard()
        elif name=="FPS & Latency":self.tweaks_page()
        elif name=="KBM Macros":self.macros_page()
        elif name=="Game Profiles":self.profiles_page()
        else:self.restore_page()

    def dashboard(self):
        self.label(self.content,"Performance Dashboard",19,TEXT,True).pack(anchor="w")
        self.label(self.content,"Real system readings and reversible, per-game controls.",9,MUTED).pack(anchor="w",pady=(3,13))
        row=tk.Frame(self.content,bg=BG);row.pack(fill="x",pady=(0,12))
        for title,var,sub in [("CPU LOAD",self.cpu,"System-wide utilization"),("MEMORY",self.ram,"Physical RAM in use"),("SYSTEM DRIVE",self.disk,"Space used")]:
            c=self.card(row,title,sub);c.pack(side="left",fill="both",expand=True,padx=(0,9))
            self.label(c,var.get(),22,TEXT,True).pack(anchor="w",padx=14,pady=(0,12))
            # Keep references so periodic update can refresh the visible values.
            if title=="CPU LOAD": self.cpu_label=c.winfo_children()[-1]
            elif title=="MEMORY": self.ram_label=c.winfo_children()[-1]
            else:self.disk_label=c.winfo_children()[-1]
        row2=tk.Frame(self.content,bg=BG);row2.pack(fill="both",expand=True)
        left=tk.Frame(row2,bg=BG);left.pack(side="left",fill="both",expand=True,padx=(0,10))
        right=tk.Frame(row2,bg=BG,width=290);right.pack(side="left",fill="y");right.pack_propagate(False)
        c=self.card(left,"One-click game optimization","This only changes the selected game's process priority; it does not promise higher FPS.")
        c.pack(fill="x",pady=(0,12))
        ln=tk.Frame(c,bg=PANEL);ln.pack(fill="x",padx=14,pady=(3,9))
        self.game_combo=ttk.Combobox(ln,state="readonly",width=30);self.game_combo.pack(side="left",fill="x",expand=True)
        self.game_combo.bind("<<ComboboxSelected>>",self._select_game)
        self.btn(ln,"Add .exe",self.add_game).pack(side="left",padx=7)
        pr=tk.Frame(c,bg=PANEL);pr.pack(fill="x",padx=14,pady=(0,8))
        self.label(pr,"Priority",9).pack(side="left")
        ttk.Combobox(pr,textvariable=self.priority,values=["Normal","Above normal","High"],state="readonly",width=17).pack(side="right")
        actions=tk.Frame(c,bg=PANEL);actions.pack(fill="x",padx=14,pady=(0,12))
        self.btn(actions,"▶ Launch game",self.launch,True).pack(side="left")
        self.btn(actions,"⚡ Optimize",self.optimize,True).pack(side="left",padx=7)
        self.btn(actions,"↶ Undo",self.undo).pack(side="left")
        c2=self.card(left,"Quick access","Windows opens its own official settings pages.")
        c2.pack(fill="x")
        ln=tk.Frame(c2,bg=PANEL);ln.pack(fill="x",padx=14,pady=(3,12))
        self.btn(ln,"Game Mode",lambda:self.open_settings("ms-settings:gaming-gamemode")).pack(side="left")
        self.btn(ln,"Graphics",lambda:self.open_settings("ms-settings:display-graphics")).pack(side="left",padx=7)
        self.btn(ln,"Startup apps",lambda:self.open_settings("ms-settings:startupapps")).pack(side="left")
        c3=self.card(right,"Live status","Readings are system-wide; in-game FPS and ping are not measured.")
        c3.pack(fill="x",pady=(0,12))
        self.label(c3,"Selected profile",8,MUTED).pack(anchor="w",padx=14,pady=(3,2))
        self.game_status=self.label(c3,"No game selected",10,TEXT,True,wraplength=240,justify="left")
        self.game_status.pack(anchor="w",padx=14,pady=(0,10))
        self.status_label=self.label(c3,self.status.get(),9,PURPLE_HI,bg=PANEL2,wraplength=235,justify="left",padx=10,pady=10)
        self.status_label.pack(fill="x",padx=12,pady=(0,12))
        c4=self.card(right,"Honest performance","Best first steps: enable Game Mode, set the game's graphics preference, close heavy background apps, and use a suitable monitor refresh rate.")
        c4.pack(fill="x")
        self._refresh_games()

    def tweaks_page(self):
        self.label(self.content,"FPS & Input Latency",19,TEXT,True).pack(anchor="w")
        self.label(self.content,"Safe controls that avoid risky registry edits or disabling Windows protections.",9,MUTED).pack(anchor="w",pady=(3,14))
        c=self.card(self.content,"Windows gaming settings","These buttons open Windows settings for you to review and change manually.")
        c.pack(fill="x",pady=(0,12))
        for txt,uri,desc in [
            ("Game Mode","ms-settings:gaming-gamemode","Helps Windows prioritize gaming workloads on supported systems."),
            ("Graphics preference","ms-settings:display-graphics","Choose High performance for a game when your PC has multiple GPUs."),
            ("Display refresh rate","ms-settings:display-advanced","Set the highest refresh rate your monitor actually supports."),
            ("Startup apps","ms-settings:startupapps","Disable only apps you recognize and do not need at startup.")
        ]:
            r=tk.Frame(c,bg=PANEL);r.pack(fill="x",padx=14,pady=5)
            self.label(r,txt,10,TEXT,True).pack(anchor="w")
            self.label(r,desc,8,MUTED,wraplength=700,justify="left").pack(anchor="w",pady=(2,5))
            self.btn(r,"Open settings",lambda u=uri:self.open_settings(u)).pack(anchor="e")
        c2=self.card(self.content,"Per-game process priority","Use Normal or Above normal first. High may make other apps less responsive; avoid Realtime.")
        c2.pack(fill="x",pady=(0,12))
        self.btn(c2,"Go to Dashboard",lambda:self.show_page("Dashboard"),True).pack(anchor="w",padx=14,pady=(3,12))
        c3=self.card(self.content,"What this app does NOT do","No fake FPS counter, no fake ping improvements, no memory cleaner, no service-killing script, and no anti-cheat bypass.")
        c3.pack(fill="x")

    def profiles_page(self):
        self.label(self.content,"Game Profiles",19,TEXT,True).pack(anchor="w")
        self.label(self.content,"Add the actual game's .exe. Profiles are stored locally.",9,MUTED).pack(anchor="w",pady=(3,14))
        c=self.card(self.content,"Saved games","Profiles are shortcuts to executables, not game modifications.")
        c.pack(fill="both",expand=True)
        self.profile_tree=ttk.Treeview(c,columns=("path",),show="headings",height=12)
        self.profile_tree.heading("path",text="Executable path");self.profile_tree.column("path",width=720)
        self.profile_tree.pack(fill="both",expand=True,padx=14,pady=8)
        self._populate_tree()
        r=tk.Frame(c,bg=PANEL);r.pack(fill="x",padx=14,pady=(0,12))
        self.btn(r,"Add game .exe",self.add_game,True).pack(side="left")
        self.btn(r,"Remove selected",self.remove_game).pack(side="left",padx=8)
        self.btn(r,"Launch selected",self.launch).pack(side="left")

    def macros_page(self):
        self.label(self.content,"KBM Macro Studio",19,TEXT,True).pack(anchor="w")
        self.label(self.content,"Record and replay simple keyboard/mouse sequences for personal workflows or games that explicitly allow macros.",9,MUTED).pack(anchor="w",pady=(3,12))
        if keyboard is None or mouse is None:
            c=self.card(self.content,"Macro support needs one optional package","Install pynput to enable local keyboard/mouse recording. No network access is used.")
            c.pack(fill="x",pady=(0,12))
            self.label(c,"py -m pip install pynput",10,TEXT,True).pack(anchor="w",padx=14,pady=(0,12))
        c=self.card(self.content,"Macro recorder","Use only where macros are permitted. Some competitive games prohibit automation; check each game's rules. No anti-cheat evasion is included.")
        c.pack(fill="x",pady=(0,12))
        r=tk.Frame(c,bg=PANEL);r.pack(fill="x",padx=14,pady=5)
        self.label(r,"Profile name",9).pack(side="left")
        tk.Entry(r,textvariable=self.macro_name,bg=PANEL2,fg=TEXT,insertbackground=TEXT,relief="flat",width=24).pack(side="left",padx=8,ipady=5)
        self.label(r,"Playback delay (ms)",9).pack(side="left",padx=(16,5))
        tk.Entry(r,textvariable=self.macro_delay,bg=PANEL2,fg=TEXT,insertbackground=TEXT,relief="flat",width=7).pack(side="left",ipady=5)
        self.label(c,"Record captures key/button presses and approximate delays. It does not capture typed text or mouse movement.",8,MUTED).pack(anchor="w",padx=14,pady=(4,8))
        buttons=tk.Frame(c,bg=PANEL);buttons.pack(fill="x",padx=14,pady=(0,12))
        self.btn(buttons,"● Start recording",self.start_record,True).pack(side="left")
        self.btn(buttons,"■ Stop & save",self.stop_record).pack(side="left",padx=8)
        self.btn(buttons,"▶ Play selected",self.play_macro).pack(side="left")
        self.btn(buttons,"■ Stop playback",self.stop_macro).pack(side="left",padx=8)
        self.label(c,self.macro_status.get(),9,PURPLE_HI).pack(anchor="w",padx=14,pady=(0,10))
        c2=self.card(self.content,"Saved macros","Select a saved macro, then play it manually. Playback can be stopped at any time.")
        c2.pack(fill="both",expand=True)
        self.macro_tree=ttk.Treeview(c2,columns=("name","events"),show="headings",height=7)
        self.macro_tree.heading("name",text="Macro");self.macro_tree.heading("events",text="Recorded actions")
        self.macro_tree.column("name",width=260);self.macro_tree.column("events",width=130)
        self.macro_tree.pack(fill="both",expand=True,padx=14,pady=8)
        r=tk.Frame(c2,bg=PANEL);r.pack(fill="x",padx=14,pady=(0,12))
        self.btn(r,"Delete selected",self.delete_macro).pack(side="left")
        self._refresh_macros()

    def restore_page(self):
        self.label(self.content,"Restore / Undo",19,TEXT,True).pack(anchor="w")
        self.label(self.content,"TRXZY Tweaks avoids persistent system-wide changes by default.",9,MUTED).pack(anchor="w",pady=(3,14))
        c=self.card(self.content,"Undo process priority","Restore the original priority captured before the last optimization. The same game process must still be running.")
        c.pack(fill="x",pady=(0,12))
        self.btn(c,"↶ Undo last priority change",self.undo,True).pack(anchor="w",padx=14,pady=(3,12))
        c2=self.card(self.content,"Macro safety","Stop playback if you need to. Closing the app stops macro playback. Do not use macros to bypass anti-cheat or violate game rules.")
        c2.pack(fill="x",pady=(0,12))
        self.btn(c2,"Stop macro playback",self.stop_macro).pack(anchor="w",padx=14,pady=(3,12))
        c3=self.card(self.content,"Local configuration","Profiles and macro sequences are saved under %APPDATA%\\TRXZYTweaks.")
        c3.pack(fill="x")
        self.btn(c3,"Open config folder",self.open_config).pack(anchor="w",padx=14,pady=(3,12))

    def _set_status(self,msg,color=PURPLE_HI):
        self.status.set(msg)
        if hasattr(self,"status_label"):
            self.status_label.configure(text=msg,fg=color)

    def _refresh_games(self):
        if hasattr(self,"game_combo"):
            names=[g["name"] for g in self.data.get("games",[])]
            self.game_combo["values"]=names
            selected=self.data.get("selected_game","")
            if selected in names:self.game_combo.set(selected)
            elif names:self.game_combo.current(0);self.data["selected_game"]=names[0];save_config(self.data)
            else:self.game_combo.set("")
            self._select_game()
        if hasattr(self,"profile_tree"):self._populate_tree()
    def _populate_tree(self):
        if not hasattr(self,"profile_tree"):return
        for item in self.profile_tree.get_children():self.profile_tree.delete(item)
        for g in self.data.get("games",[]):self.profile_tree.insert("", "end", iid=g["path"], values=(g["path"],),text=g["name"])
    def _selected_game(self):
        name=self.game_combo.get() if hasattr(self,"game_combo") else self.data.get("selected_game","")
        return next((g for g in self.data.get("games",[]) if g["name"]==name),None)
    def _select_game(self,event=None):
        g=self._selected_game()
        if g:
            self.data["selected_game"]=g["name"];save_config(self.data)
            if hasattr(self,"game_status"):self.game_status.configure(text=g["name"])
        elif hasattr(self,"game_status"):self.game_status.configure(text="No game selected")
    def add_game(self):
        path=filedialog.askopenfilename(title="Choose game executable",filetypes=[("Windows executable","*.exe")])
        if not path:return
        if any(g["path"].lower()==path.lower() for g in self.data["games"]):
            messagebox.showinfo(APP_NAME,"That executable is already in your profiles.");return
        name=os.path.splitext(os.path.basename(path))[0]
        self.data["games"].append({"name":name,"path":path});self.data["selected_game"]=name
        save_config(self.data);self._refresh_games();self._set_status(f"Added profile: {name}",GREEN)
    def remove_game(self):
        g=self._selected_game()
        if not g:messagebox.showinfo(APP_NAME,"Choose a profile first.");return
        if not messagebox.askyesno(APP_NAME,f"Remove profile '{g['name']}'? The game will not be deleted."):return
        self.data["games"]=[x for x in self.data["games"] if x["path"]!=g["path"]]
        self.data["selected_game"]="";save_config(self.data);self._refresh_games()
    def launch(self):
        g=self._selected_game()
        if not g:messagebox.showinfo(APP_NAME,"Add a game .exe first.");return
        if not os.path.isfile(g["path"]):messagebox.showerror(APP_NAME,"Executable not found. Remove and add the profile again.");return
        try:
            self.running=subprocess.Popen([g["path"]],cwd=os.path.dirname(g["path"]))
            self._set_status(f"Launched {g['name']}.",GREEN)
        except OSError as e:messagebox.showerror(APP_NAME,str(e))
    def _open_proc(self,pid):
        if os.name!="nt" or KERNEL32 is None:raise RuntimeError("Windows only.")
        KERNEL32.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
        KERNEL32.OpenProcess.restype=wintypes.HANDLE
        h=KERNEL32.OpenProcess(PROC_QUERY|PROC_SET,False,int(pid))
        if not h:raise ctypes.WinError(ctypes.get_last_error())
        return h
    def _get_priority(self,pid):
        h=self._open_proc(pid)
        try:
            KERNEL32.GetPriorityClass.argtypes=[wintypes.HANDLE];KERNEL32.GetPriorityClass.restype=wintypes.DWORD
            v=KERNEL32.GetPriorityClass(h)
            if not v:raise ctypes.WinError(ctypes.get_last_error())
            return v
        finally:KERNEL32.CloseHandle(h)
    def _set_priority(self,pid,v):
        h=self._open_proc(pid)
        try:
            KERNEL32.SetPriorityClass.argtypes=[wintypes.HANDLE,wintypes.DWORD];KERNEL32.SetPriorityClass.restype=wintypes.BOOL
            if not KERNEL32.SetPriorityClass(h,int(v)):raise ctypes.WinError(ctypes.get_last_error())
        finally:KERNEL32.CloseHandle(h)
    def _find_pid(self):
        g=self._selected_game()
        if not g:return None
        if psutil:
            for p in psutil.process_iter(["pid","name","exe"]):
                try:
                    if (p.info.get("exe") or "").lower()==g["path"].lower() or (p.info.get("name") or "").lower()==os.path.basename(g["path"]).lower():
                        return p.info["pid"]
                except (psutil.NoSuchProcess,psutil.AccessDenied):pass
        if self.running and self.running.poll() is None:return self.running.pid
        return None
    def optimize(self):
        if os.name!="nt":messagebox.showerror(APP_NAME,"Windows 10/11 is required.");return
        pid=self._find_pid()
        if not pid:messagebox.showinfo(APP_NAME,"The selected game is not running. Launch it first.");return
        try:
            old=self._get_priority(pid);new=PRIORITIES.get(self.priority.get(),PRIORITIES["Above normal"])
            self._set_priority(pid,new);self.changed_pid=pid;self.old_priority=old
            self._set_status(f"Applied {self.priority.get()} priority to game PID {pid}. Undo is available.",GREEN)
        except Exception as e:messagebox.showerror(APP_NAME,f"Could not change priority. Some games restrict this action.\n\n{e}")
    def undo(self):
        if self.changed_pid is None or self.old_priority is None:
            self._set_status("Nothing to undo.",MUTED);return
        try:
            self._set_priority(self.changed_pid,self.old_priority)
            self._set_status(f"Restored original priority for PID {self.changed_pid}.",GREEN)
            self.changed_pid=None;self.old_priority=None
        except Exception as e:
            messagebox.showwarning(APP_NAME,f"Could not restore. The game may have closed.\n\n{e}")
    def open_settings(self,uri):
        try:os.startfile(uri)
        except Exception as e:messagebox.showerror(APP_NAME,f"Could not open Windows Settings.\n{e}")
    def open_config(self):
        os.makedirs(CONFIG_DIR,exist_ok=True)
        try:os.startfile(CONFIG_DIR)
        except Exception as e:messagebox.showerror(APP_NAME,str(e))
    def _stats(self):
        if psutil:
            try:
                cpu=psutil.cpu_percent(interval=None);mem=psutil.virtual_memory()
                self.cpu.set(f"{cpu:.0f}%");self.ram.set(f"{mem.percent:.0f}%")
                try:self.disk.set(f"{psutil.disk_usage(os.environ.get('SystemDrive','C:')+'\\\\').percent:.0f}% full")
                except Exception:self.disk.set("Unavailable")
                for attr,var in [("cpu_label",self.cpu),("ram_label",self.ram),("disk_label",self.disk)]:
                    if hasattr(self,attr):getattr(self,attr).configure(text=var.get())
            except Exception:pass
        else:
            self.cpu.set("Install psutil");self.ram.set("Install psutil");self.disk.set("Install psutil")
        self.root.after(1300,self._stats)

    # Macro recording/playback via pynput. Playback is manual, local, and stoppable.
    def _macro_record_key(self,key):
        try:
            if isinstance(key,keyboard.Key):name="key:"+str(key).replace("Key.","")
            else:name="char:"+key.char
            self.record_events.append({"kind":"key","name":name,"t":time.perf_counter()-self.record_start})
        except Exception:pass
    def _macro_record_mouse(self,x,y,button,pressed):
        if pressed:
            self.record_events.append({"kind":"mouse","name":str(button).replace("Button.",""),"t":time.perf_counter()-self.record_start})
    def start_record(self):
        if keyboard is None or mouse is None:
            messagebox.showinfo(APP_NAME,"Install the optional macro package first:\npy -m pip install pynput");return
        if self.recording:return
        self.record_events=[];self.record_start=time.perf_counter();self.recording=True
        try:
            self.record_listener=keyboard.Listener(on_press=self._macro_record_key)
            self.record_mouse_listener=mouse.Listener(on_click=self._macro_record_mouse)
            self.record_listener.start();self.record_mouse_listener.start()
            self.macro_status.set("Recording input… click Stop & save when finished.")
            self._set_status("KBM recording started. Stop it when finished.",GREEN)
        except Exception as e:
            self.recording=False;messagebox.showerror(APP_NAME,f"Could not start recording:\n{e}")
    def stop_record(self):
        if not self.recording:return
        self.recording=False
        try:
            self.record_listener.stop();self.record_mouse_listener.stop()
        except Exception:pass
        name=self.macro_name.get().strip() or f"Macro {len(self.data['macros'])+1}"
        if self.record_events:
            self.data.setdefault("macros",[]).append({"name":name,"events":self.record_events})
            save_config(self.data);self._refresh_macros()
            self.macro_status.set(f"Saved '{name}' with {len(self.record_events)} actions.")
        else:self.macro_status.set("No key/button presses captured.")
    def _refresh_macros(self):
        if not hasattr(self,"macro_tree"):return
        for i in self.macro_tree.get_children():self.macro_tree.delete(i)
        for i,m in enumerate(self.data.get("macros",[])):
            self.macro_tree.insert("","end",iid=str(i),values=(m.get("name","Macro"),len(m.get("events",[]))))
    def _selected_macro_index(self):
        if not hasattr(self,"macro_tree"):return None
        s=self.macro_tree.selection()
        return int(s[0]) if s else None
    def delete_macro(self):
        i=self._selected_macro_index()
        if i is None:return
        del self.data["macros"][i];save_config(self.data);self._refresh_macros()
    def play_macro(self):
        if keyboard is None or mouse is None:
            messagebox.showinfo(APP_NAME,"Install pynput first: py -m pip install pynput");return
        i=self._selected_macro_index()
        if i is None:messagebox.showinfo(APP_NAME,"Select a saved macro first.");return
        if self.macro_playing:return
        try:delay=max(10,min(2000,int(self.macro_delay.get())))
        except ValueError:messagebox.showerror(APP_NAME,"Playback delay must be a number of milliseconds.");return
        macro=self.data["macros"][i]
        if not messagebox.askyesno(APP_NAME,f"Play '{macro['name']}'?\n\nOnly use macros in apps/games that permit automation. Playback sends real keyboard/mouse input."):
            return
        self.stop_playback.clear();self.macro_playing=True
        self.macro_status.set(f"Playing '{macro['name']}'… use Stop playback to interrupt.")
        threading.Thread(target=self._play_worker,args=(macro,delay),daemon=True).start()
    def _play_worker(self,macro,delay_ms):
        kb=keyboard.Controller();ms=mouse.Controller()
        last=0.0
        try:
            for ev in macro.get("events",[]):
                if self.stop_playback.is_set():break
                t=float(ev.get("t",last))
                wait=max(0,min(2.0,t-last))
                if wait:self.stop_playback.wait(max(wait,delay_ms/1000.0))
                if self.stop_playback.is_set():break
                name=ev.get("name","")
                try:
                    if ev.get("kind")=="key":
                        if name.startswith("char:"):
                            k=name[5:]
                        else:
                            attr=name[4:] if name.startswith("key:") else ""
                            k=getattr(keyboard.Key,attr,None)
                        if k is not None:kb.press(k);kb.release(k)
                    elif ev.get("kind")=="mouse":
                        btn=getattr(mouse.Button,name,None)
                        if btn is not None:ms.click(btn)
                except Exception:pass
                last=t
        finally:
            self.macro_playing=False
            msg="Playback stopped." if self.stop_playback.is_set() else "Macro playback complete."
            try:self.root.after(0,lambda:self.macro_status.set(msg))
            except Exception:pass
    def stop_macro(self):
        self.stop_playback.set()
        self.macro_status.set("Stop requested.")
    def close(self):
        self.stop_playback.set()
        if self.recording:
            try:self.record_listener.stop();self.record_mouse_listener.stop()
            except Exception:pass
        if self.changed_pid is not None and self.old_priority is not None:
            try:self._set_priority(self.changed_pid,self.old_priority)
            except Exception:pass
        self.root.destroy()

def main():
    root=tk.Tk();App(root);root.mainloop()
if __name__=="__main__":main()
